import React, { memo } from 'react';

function Post({ productImageUrl, title, url, votes, description, submitterAvatarUrl, upvote, downvote, onRemove }) {
    return (
        <>
            <div className='item'>
                <div className='image'>
                    <img src={productImageUrl} alt={"Image " + title} />
                </div>
                <div className='middle aligned content'>
                    <div className='header'>
                        <span onClick={upvote} style={{ marginRight: '15px' }}>
                            UP
                        </span>
                        {votes}
                        <span onClick={downvote} style={{ marginLeft: '15px' }}>
                            DOWN
                        </span>
                    </div>
                    <div className='description'>
                        <a href={url}>
                            {title} <span className="remove" onClick={onRemove}>(Supprimer)</span>
                        </a>
                        <p>
                            {description}
                        </p>
                    </div>
                    <div className='extra'>
                        <span>Ajouté par:</span>
                        <img
                            className='ui avatar image'
                            src={submitterAvatarUrl}
                            alt="profile"
                        />
                    </div>
                </div>
            </div>
            <hr />
        </>
    );
}

export default memo(Post);