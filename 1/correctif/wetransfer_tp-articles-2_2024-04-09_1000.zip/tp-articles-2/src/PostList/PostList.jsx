import { useState } from "react";
import { MOCK_POSTS } from "../mocks/posts.mock";
import { Post } from "./Post/Post";

export default function PostList() {
  const [posts, setPosts] = useState([...MOCK_POSTS]);

  function handleProductVote(postId, type) {
    const value = type === "up" ? 1 : -1;

    const nextPosts = posts.map((post) => {
      if (post.id === postId) {
        return { ...post, votes: post.votes + value };
      } else {
        return post;
      }
    });
    setPosts(nextPosts);
  }

  function handleDelete(postId) {
    const nextPosts = posts.filter((post) => {
      return post.id !== postId;
    });
    setPosts(nextPosts);
  }

  const postsDisplay = [...posts].sort((a, b) => b.votes - a.votes);
  const postComponents = postsDisplay
    .filter((post) => {
      return post.votes >= 0;
    })
    .map((post) => (
      <Post
        key={"post-" + post.id}
        id={post.id}
        title={post.title}
        description={post.description}
        url={post.url}
        votes={post.votes}
        submitterAvatarUrl={post.submitterAvatarUrl}
        productImageUrl={post.productImageUrl}
        color={"blue"}
        uppercase={true}
        onVote={handleProductVote}
        onDelete={handleDelete}
      />
    ));

  return <div className="ui unstackable items">{postComponents}</div>;
}
