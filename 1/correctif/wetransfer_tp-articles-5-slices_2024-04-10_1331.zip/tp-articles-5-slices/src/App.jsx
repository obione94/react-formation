import { BrowserRouter as Router, Routes, Route, Navigate  } from 'react-router-dom';
import './App.css';
import Login from './pages/Login/Login';
import Home from './pages/Home/Home';
import PostList from './pages/Home/components/PostList';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="login" element={<Login />} />
          <Route path="home" element={<Home />} >
            <Route path="" element={<PostList />} />
          </Route>
          <Route path="*" element={<Navigate to="/login" />} /> 
        </Routes>
      </Router>
    </div>
  );
}

export default App;
