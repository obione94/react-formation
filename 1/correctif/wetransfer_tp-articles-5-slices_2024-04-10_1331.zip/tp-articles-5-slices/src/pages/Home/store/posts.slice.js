import { createSlice } from '@reduxjs/toolkit'
import MOCK_POSTS from '../datas/post.mock';

const initialState = [...MOCK_POSTS];

function getIndex(state, id) {
    return state.findIndex(p => p.id === id);
}

const postsSlice = createSlice({
    name: 'posts',
    initialState,
    reducers: {
        upvote(state, action) {
            const index = getIndex(state, action.payload);
            state[index].votes++; // IMMER JS
        },
        downvote(state, action) {
            const index = getIndex(state, action.payload);
            state[index].votes--;
        },
        remove(state, action) {
            const index = getIndex(state, action.payload);
            state.splice(index, 1);
        },
        removeAll(state) {
            state.splice(0, state.length);
        }
    },
})

export const { upvote, downvote, remove, removeAll } = postsSlice.actions
export default postsSlice.reducer