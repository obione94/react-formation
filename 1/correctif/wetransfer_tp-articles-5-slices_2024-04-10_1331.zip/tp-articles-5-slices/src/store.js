import { combineReducers } from "redux";
import { configureStore } from '@reduxjs/toolkit'
import postsReducer from "./pages/Home/store/posts.slice";

// combineReducer permet d'appliquer plusieurs reducers
const combinedReducers = combineReducers({
    postsReducer // postReducer: postReducer
});

// Appliquer la nouvelle bonne pratique
const store = configureStore({
    reducer: combinedReducers
});

export default store;