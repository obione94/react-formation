import PostList from './components/PostList/PostList';

export default function Home() {
    return (
        <div>
            <h1>Page d'accueil</h1>

            <hr/>
            <PostList />
        </div>
    )
}