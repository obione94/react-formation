import * as Yup from 'yup';

const LoginSchema = Yup.object().shape({
    pseudo: Yup.string()
        .required('Veuillez indiquer le nom d\'utilisateur'),
    password: Yup.string()
        .required('Le mot de passe est requis pour la connexion')
});

export { LoginSchema }