import Vote from './Vote/Vote';
import PropTypes from 'prop-types';

export function Post(props) {
  const {
    onDelete,
    id,
    onVote,
    votes,
    title,
    url,
    description,
    submitterAvatarUrl,
    productImageUrl,
    color = 'black',
    uppercase = false
  } = props;

  return (
    <div className="item">
      <button onClick={() => onDelete(id)}>Supprimer</button>
      <div className="image">
        <img src={productImageUrl} />
      </div>
      <div className="middle aligned content">
        <div className="header">
          <Vote id={id} onVote={onVote} votes={votes} />
        </div>
        <div className="description">
          <a href={url} style={{color, textTransform: uppercase ? 'uppercase' : 'normal'}}>{title}</a>
          <p>{description}</p>
        </div>
        <div className="extra">
          <span>Ajouté par:</span>
          <img className="ui avatar image" src={submitterAvatarUrl} />
        </div>
      </div>
    </div>
  );
}

Post.propTypes = {
  onDelete: PropTypes.func.isRequired,
  onVote: PropTypes.func.isRequired,
  id: PropTypes.number.isRequired,
  votes: PropTypes.number.isRequired,
  title: PropTypes.string.isRequired,
  url: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  submitterAvatarUrl: PropTypes.string.isRequired,
  productImageUrl: PropTypes.string.isRequired,
  color: PropTypes.string,
  uppercase: PropTypes.bool,
}