import withSecured from "../../guards/secured";
import { Outlet } from "react-router-dom";

function Home() {
  return (
    <div>
      <Outlet />
    </div>
  );
}

// En React, ce qui commence par with indique qu'on fait appelle à un HOC (High Order Component)
export default withSecured(Home);
