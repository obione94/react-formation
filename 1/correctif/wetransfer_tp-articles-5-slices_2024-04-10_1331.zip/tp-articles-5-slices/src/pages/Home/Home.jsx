import withSecured from "../../guards/secured";
import { Outlet } from "react-router-dom";

function Home() {
  return (
    <div>
      <Outlet />
    </div>
  );
}

export default withSecured(Home);
