import React from "react";
import { Navigate } from "react-router";

const withSecured = (Component) => {
  // Renvoyer le nouveau composant
  return ({ ...props }) => {
    if (!localStorage.getItem("TOKEN")) { // TODO Aller demander au backend si le token est valide !
      return <Navigate to="/login" />;
    }

    return <Component {...props} />;
  };
};

export default withSecured;