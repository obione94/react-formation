import { useFormLogin } from "./forms/login.form";

export default function Login() {
  const { loadingSubmit, error, formik } = useFormLogin();

  return (
    <div>
      <h2>Page de connexion</h2>

      {error && <div className="bloc-error">{error}</div>}

      <form onSubmit={formik.handleSubmit}>
        <input
          type="text"
          name="pseudo"
          placeholder="Nom d'utilisateur"
          onChange={formik.handleChange}
          value={formik.values.pseudo}
        />
        {formik.errors.pseudo && (
          <div className="error">{formik.errors.pseudo}</div>
        )}
        <br />

        <input
          type="text"
          name="password"
          placeholder="Mot de passe"
          onChange={formik.handleChange}
          value={formik.values.password}
        />
        {formik.errors.password && (
          <div className="error">{formik.errors.password}</div>
        )}
        <br />

        <button
          type="submit"
          disabled={loadingSubmit || !formik.dirty || !formik.isValid}
        >
          Me connecter
        </button>
      </form>
    </div>
  );
}
