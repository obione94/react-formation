import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Post from './Post';
import { upvote, downvote, remove, removeAll } from '../store/posts.slice';

function PostList() {
    const posts = useSelector((state) => state.postsReducer);
    const dispatch = useDispatch();

    // La méthode sort modifie l'array initiale, slice permet de le cloner d'abord
    const postsSorted = posts.slice().sort((a, b) => (
        b.votes - a.votes
    ));
    const postComponents = postsSorted.map((post) => (
        <Post
            key={'post-' + post.id}
            id={post.id}
            title={post.title}
            description={post.description}
            url={post.url}
            votes={post.votes}
            submitterAvatarUrl={post.submitterAvatarUrl}
            productImageUrl={post.productImageUrl}
            upvote={() => dispatch(upvote(post.id))}
            downvote={() => dispatch(downvote(post.id))}
            onRemove={() => dispatch(remove(post.id))}
        />
    ));

    return (
        <div className='ui unstackable items'>
            <button onClick={() => dispatch(removeAll())}>Tout supprimer</button>
            <hr/>
            {postComponents}
        </div>
    );
}

export default PostList;