import React from 'react';
import PropTypes from 'prop-types';

export default function Vote(props) {
    function handleVote(typeVote) {
        props.onVote(props.id, typeVote)
    }

    return (
        <div>
            <a onClick={() => handleVote('up')}>
                <i className='large caret up icon' />
            </a>
            {props.votes}
            <a onClick={() => handleVote('down')}>
                <i className='large caret down icon' />
            </a>
        </div>
    );
}

Vote.propTypes = {
    onVote: PropTypes.func.isRequired,
    id: PropTypes.number.isRequired,
}