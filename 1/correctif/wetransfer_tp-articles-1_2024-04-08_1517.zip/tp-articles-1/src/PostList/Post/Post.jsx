import Vote from './Vote/Vote';

export function Post(props) {
    const {
      onDelete,
      id,
      onVote,
      votes,
      title,
      url,
      description,
      submitterAvatarUrl,
      productImageUrl,
    } = props;

    return (
      <div className="item">
        <button onClick={() => onDelete(id)}>Supprimer</button>
        <div className="image">
          <img src={productImageUrl} />
        </div>
        <div className="middle aligned content">
          <div className="header">
            <Vote id={id} onVote={onVote} votes={votes} />
          </div>
          <div className="description">
            <a href={url}>{title}</a>
            <p>{description}</p>
          </div>
          <div className="extra">
            <span>Ajouté par:</span>
            <img className="ui avatar image" src={submitterAvatarUrl} />
          </div>
        </div>
      </div>
    );
}
