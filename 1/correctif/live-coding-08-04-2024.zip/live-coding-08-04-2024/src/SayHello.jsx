import { useState } from 'react'
import MOCK_USERS from './users.mock'

// Un composant, c'est une fonction qui renvoie une vue.
function DireBonjour({}) {
  // Cette variable doit être réactive
  const [users, setUsers] = useState(MOCK_USERS)

  function onDeleteUser(index) {
    // INTERDIT DE MODIFIER UN ETAT PRECEDENT
    const newUsers = [...users]
    newUsers.splice(index, 1)

    setUsers(newUsers) // Création du nouvel état
  }

  function onRenameUser(index) {
    // INTERDIT DE MODIFIER UN ETAT PRECEDENT
    // const newUsers = [...users]
    // MAUVAISE PRATIQUE ICI !!!
    // newUsers[index].name = newUsers[index].name + ' 1'

    // Bonne pratique
    const newUsers = users.map((u, i) => {
      if (i === index) {
        return {
          ...u,
          name: u.name + ' 1',
        }
      }

      return u
    })

    setUsers(newUsers) // Création du nouvel état
  }

  return (
    <div>
      {users.map((u, i) => (
        <li key={u.id}>
          {u.name} - {u.age} ans
          <button onClick={() => onDeleteUser(i)}>Supprimer</button>
          <button onClick={() => onRenameUser(i)}>Modifier le prénom</button>
        </li>
      ))}
    </div>
  )
}

export default DireBonjour
