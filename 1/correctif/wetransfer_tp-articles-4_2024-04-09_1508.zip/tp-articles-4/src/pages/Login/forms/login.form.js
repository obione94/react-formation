import { useFormik } from "formik";
import { useState } from "react";
import { LoginSchema } from "../schemas/login.schema";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function mockBackendCall() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve({
                data: {
                    token: 'Token fictif.'
                }
            });
        }, 2000);
    })
}

const useFormLogin = () => {
    const [loadingSubmit, setLoadingLogin] = useState(false);
    const [error, setError] = useState(null);
    const nav = useNavigate();

    const formik = useFormik({
        initialValues: {
            pseudo: "",
            password: "",
        },
        validationSchema: LoginSchema,
        onSubmit: (values) => {
            handleSubmit(values);
        },
    });

    function handleSubmit(values) {
        setError(null);
        setLoadingLogin(true);

        mockBackendCall()
            // axios // Permet de réaliser un véritable appel au backend
            //   .post("https://serveur-demo.m2g-intellect.fr/login", values)
            .then((res) => {
                localStorage.setItem('TOKEN', res.data.token);
                nav('/home');
            })
            .catch((error) => setError(error.response.data.error))
            .finally(() => setLoadingLogin(false));
    }

    return { loadingSubmit, error, formik };
};

export { useFormLogin };