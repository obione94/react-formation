import PostList from './PostList/PostList';

function App() {
  return (
    <div>
      <PostList />
    </div>
  );
}

export default App;
