import { useNavigate } from "react-router";

export default function Login() {
    const nav = useNavigate();

    function onLogin() {
        nav('/home');
    }

    return (
        <div>
            <h1>Page de connexion</h1>

            <div>
                <button onClick={onLogin}>Me connecter</button>
            </div>
        </div>
    )
}