import { useState } from 'react'
import './App.css'
import DireBonjour from './SayHello'

function App() {
  let [counter, setCounter] = useState(0)

  function incrementX10() {
    for (let i = 0; i < 10; i++) {
      setCounter((cc) => cc + 1)
      // setCounter(counter + 1) // Asynchrone
      // 1. setCounter(0 + 1) // cc = 1
      // 2. setCounter(1 + 1) // cc = 2
      // 3. setCounter(2 + 1) // cc = 3
      // 4. setCounter(3 + 1) // cc = 4
      // 5. setCounter(4 + 1) // cc = 5
      // ..
      // 10. setCounter(9 + 1)
    }
  }

  return (
    // JSX
    <div className="App">
      <h1>Notre premier projet React.</h1>

      <button onClick={() => setCounter(counter - 1)}>-</button>
      <span>{counter}</span>
      <button onClick={() => setCounter(counter + 1)}>+</button>

      <div>
        <button onClick={incrementX10}>Incrémenter x10</button>
      </div>
      <hr />
      <DireBonjour />
    </div>
  )
}

export default App
