import React, { useEffect, useState } from 'react';
import MOCK_POSTS from '../datas/post.mock';
import Post from './Post';

export default function PostList() {
    const [products, setProducts] = useState([]);

    // Equivalent du componentDidMount
    useEffect(() => {
        setProducts(MOCK_POSTS);
    }, []);

    const handleProductVote = (productId, voteType) => {
        const value = voteType === 'up' ? 1 : -1;

        const nextProducts = products.map((product) => {
            if (product.id === productId) {
                // product.votes++; -> INTERDIT !!
                // Clone avec ES2015
                return { ...product, votes: product.votes + value };
            } else {
                return product;
            }
        });
        setProducts(nextProducts);
    }

    const handleRemove = (productId) => {
        setProducts(products.filter(p => p.id !== productId));
    }

    const productsSorted = products.slice().sort((a, b) => (
        b.votes - a.votes
    ));
    const productComponents = productsSorted.map((product) => (
        <Post
            key={'product-' + product.id}
            id={product.id}
            title={product.title}
            description={product.description}
            url={product.url}
            votes={product.votes}
            submitterAvatarUrl={product.submitterAvatarUrl}
            productImageUrl={product.productImageUrl}
            upvote={() => handleProductVote(product.id, 'up')}
            downvote={() => handleProductVote(product.id, 'down')}
            onRemove={handleRemove}
        />
    ));

    return (
        <div className='ui unstackable items'>
            {productComponents}
        </div>
    );
}
